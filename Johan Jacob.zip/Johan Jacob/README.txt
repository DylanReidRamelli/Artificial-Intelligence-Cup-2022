Author: Johan Jacob

To compile the code please use the following command in the terminal

cc     tsp.c   -o tsp -Ofast

To run the program please use the following format

./tsp <filename> <seed> <output_filename>

An example would be:

./tsp AI_cup_2022_problems/eil76.tsp 3 eil_result.txt

Please note that the seed and output_filename are not mandatory parameters to
run the program.
